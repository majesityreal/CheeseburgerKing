// sfx_lettuce_projectile sound made by wav2c

extern const unsigned int sfx_lettuce_projectile_sampleRate;
extern const unsigned int sfx_lettuce_projectile_length;
extern const signed char sfx_lettuce_projectile_data[];
