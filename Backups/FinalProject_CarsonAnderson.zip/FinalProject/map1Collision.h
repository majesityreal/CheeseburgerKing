
//{{BLOCK(map1Collision)

//======================================================================
//
//	map1Collision, 2048x256@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 524288 = 524800
//
//	Time-stamp: 2021-12-04, 19:11:10
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MAP1COLLISION_H
#define GRIT_MAP1COLLISION_H

#define map1CollisionBitmapLen 524288
extern const unsigned short map1CollisionBitmap[262144];

#define map1CollisionPalLen 512
extern const unsigned short map1CollisionPal[256];

#endif // GRIT_MAP1COLLISION_H

//}}BLOCK(map1Collision)
