// sfx_jump1 sound made by wav2c

extern const unsigned int sfx_jump1_sampleRate;
extern const unsigned int sfx_jump1_length;
extern const signed char sfx_jump1_data[];
