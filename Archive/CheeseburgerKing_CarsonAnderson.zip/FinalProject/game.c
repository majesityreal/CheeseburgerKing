#include "myLib.h"
#include "game.h"
#include "collisionMap.h"

OBJ_ATTR shadowOAM[128];
ANISPRITE pacman;
short pellets[1024];
// gets the collision map set up
unsigned char* collisionMap = collisionMapBitmap;

int score = 0;
int pelletsEaten = 0;
int level = 1;

int lives = 3;

int blueMode = 0;
int blueTimer = 0;

// pauses game when pauseVar = 1
int pauseVar = 0;

// Pacman animation states for aniState
enum {PACDOWN, PACUP, PACRIGHT, PACLEFT, PACIDLE};

// Initialize the game
// #region init
void initGame() {
    initPlayer();
}

// Initialize the player
void initPlayer() {
    pacman.hide = 0;
    pacman.width = 8;
    pacman.height = 8;
    pacman.rdel = 1;
    pacman.cdel = 1;

    // Place in the middle of the screen in the world location chosen earlier
    pacman.worldRow = 30;
    pacman.worldCol = 30;
    pacman.aniCounter = 0;
    pacman.curFrame = 0;
    pacman.numFrames = 3;
    pacman.aniState = PACDOWN;
}

// #endregion

// Updates the game each frame
void updateGame() {
    // pauses the game
    if (BUTTON_PRESSED(BUTTON_START) | BUTTON_PRESSED(BUTTON_SELECT)) {
        pauseVar = 1;
    }
	updatePlayer();
}

// Draws the game each frame
void drawGame() {

    drawPlayer();

    waitForVBlank();

    DMANow(3, shadowOAM, OAM, 128 * 4);
}

// Handle every-frame actions of the player
void updatePlayer() {

    // TODO - add gravity implementation

    if(BUTTON_HELD(BUTTON_UP) 
        && !collisionMap[OFFSET(pacman.worldCol, pacman.worldRow - 1, MAPWIDTH)]
        && !collisionMap[OFFSET(pacman.worldCol + pacman.width, pacman.worldRow - 1, MAPWIDTH) ]) {
        pacman.worldRow--;
    }
    if(BUTTON_HELD(BUTTON_DOWN) 
        && !collisionMap[OFFSET(pacman.worldCol, pacman.worldRow + pacman.height + 1, MAPWIDTH)]
        && !collisionMap[OFFSET(pacman.worldCol + pacman.width, pacman.worldRow + pacman.height + 1, MAPWIDTH)]) {
        pacman.worldRow++;
    }
    if(BUTTON_HELD(BUTTON_LEFT)
        && !collisionMap[OFFSET(pacman.worldCol - 1, pacman.worldRow, MAPWIDTH)]
        && !collisionMap[OFFSET(pacman.worldCol - 1, pacman.worldRow + pacman.height, MAPWIDTH)]) {
        pacman.worldCol--;
    }
    if(BUTTON_HELD(BUTTON_RIGHT) 
        && !collisionMap[OFFSET(pacman.worldCol + pacman.width + 1, pacman.worldRow, MAPWIDTH)]
        && !collisionMap[OFFSET(pacman.worldCol + pacman.width + 1, pacman.worldRow + pacman.height, MAPWIDTH)]) {
        pacman.worldCol++;
    }

    // TODO add player animations in
    // animatePlayer();
}

// TODO - fix up for player animation states (attack, move left/right, jump)
// Handle player animation states
void animatePlayer() {

    // Set previous state to current state
    pacman.prevAniState = pacman.aniState;
    pacman.aniState = PACIDLE;

    // Change the animation frame every 20 frames of gameplay
    if(pacman.aniCounter % 10 == 0) {
        pacman.curFrame = (pacman.curFrame + 1) % pacman.numFrames;
    }

    // Control movement and change animation state
    if(BUTTON_HELD(BUTTON_UP))
        pacman.aniState = PACUP;
    if(BUTTON_HELD(BUTTON_DOWN))
        pacman.aniState = PACDOWN;
    if(BUTTON_HELD(BUTTON_LEFT))
        pacman.aniState = PACLEFT;
    if(BUTTON_HELD(BUTTON_RIGHT))
        pacman.aniState = PACRIGHT;

    // If the pacman aniState is idle, frame is pacman standing
    if (pacman.aniState == PACIDLE) {
        pacman.curFrame = 0;
        pacman.aniCounter = 0;
        pacman.aniState = pacman.prevAniState;
    } else {
        pacman.aniCounter++;
    }
}

// Draw the player
void drawPlayer() {
    if (pacman.hide) {
        shadowOAM[0].attr0 |= ATTR0_HIDE;
    } else {
        shadowOAM[0].attr0 = (ROWMASK & pacman.worldRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & pacman.worldCol) | ATTR1_TINY;
        if (pacman.aniState == PACDOWN) {
            shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(0, 0);
        }
        else
            shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(0, 0);
    }
}

void drawFont() {
    // this draws the 'score' text
    for (int i = 0; i < 5; i++) {
        shadowOAM[2 + i].attr0 = (ROWMASK & 0) | ATTR0_SQUARE;
        shadowOAM[2 + i].attr1 = (COLMASK & ((i * 8))) | ATTR1_TINY;
        shadowOAM[2 + i].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((10 + i), 1);
    }
    // this draws the actual score
    int d3 = score / 100;
    int d2 = (score % 100) / 10;
    int d1 = score % 10;
        shadowOAM[7].attr0 = (ROWMASK & 0) | ATTR0_SQUARE;
        shadowOAM[7].attr1 = (COLMASK & (40)) | ATTR1_TINY;
        shadowOAM[7].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((10 + d3), 0);

        shadowOAM[8].attr0 = (ROWMASK & 0) | ATTR0_SQUARE;
        shadowOAM[8].attr1 = (COLMASK & (48)) | ATTR1_TINY;
        shadowOAM[8].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((10 + d2), 0);

        shadowOAM[9].attr0 = (ROWMASK & 0) | ATTR0_SQUARE;
        shadowOAM[9].attr1 = (COLMASK & (56)) | ATTR1_TINY;
        shadowOAM[9].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((10 + d1), 0);
}