
//{{BLOCK(testmapcollisionmap)

//======================================================================
//
//	testmapcollisionmap, 512x512@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 262144 = 262656
//
//	Time-stamp: 2021-11-12, 23:42:21
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TESTMAPCOLLISIONMAP_H
#define GRIT_TESTMAPCOLLISIONMAP_H

#define testmapcollisionmapBitmapLen 262144
extern const unsigned short testmapcollisionmapBitmap[131072];

#define testmapcollisionmapPalLen 512
extern const unsigned short testmapcollisionmapPal[256];

#endif // GRIT_TESTMAPCOLLISIONMAP_H

//}}BLOCK(testmapcollisionmap)
