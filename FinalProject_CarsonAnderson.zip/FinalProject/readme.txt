Cheeseburger King is a side-scrolling platformer where you travel the land of Hamburg
searching for key ingredients to the ultimate sandwich: The Cheeseburger.

=-= Controls =-=
- In game -
Arrows: Move around the world (UP for jump)
A: Attack
R/L: Dash
Start / Select: Pause/resume game
- Title Screen -
Up/Down Arrows: Move cursor
A: Select current button
B: Return to title screen

=-= Lore =-=
The King of Hamburg is dying. The whole kingdom is in mourning preparing for the loss 
of their favorite King. A servant comes to your house and tells you that the King has 
requested to speak with you specifically. What could he possibly want of you?

He explains that all his life he has had everything he has ever wanted. He ruled a 
magnificent kingdom, married the love of his life, and found solace in his mortality. 
But he explains that he has always felt that there was something missing, something 
he couldn’t quite pinpoint until now. He had a vision in the night of something new, 
something he calls the ‘Ultimate Sandwich’. He realizes that the thing that would make 
his life complete is one simple thing: a cheeseburger. 

You, the King’s most trusted servant, are instructed to go on a quest to make this 
sandwich and satisfy the King’s last wish. He says that your Quest will revolutionize 
the sandwich industry, and that people will be telling your story for the rest of the ages. 
Obediently, you embark on this Grand Quest.


Note: For legal reasons, this game could not be titled Burger King