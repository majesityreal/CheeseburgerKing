// sfx_attack sound made by wav2c

extern const unsigned int sfx_attack_sampleRate;
extern const unsigned int sfx_attack_length;
extern const signed char sfx_attack_data[];
