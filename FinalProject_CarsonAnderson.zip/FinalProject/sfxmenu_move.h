// sfxmenu_move sound made by wav2c

extern const unsigned int sfxmenu_move_sampleRate;
extern const unsigned int sfxmenu_move_length;
extern const signed char sfxmenu_move_data[];
