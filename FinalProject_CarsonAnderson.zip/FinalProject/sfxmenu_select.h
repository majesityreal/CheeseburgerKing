// sfxmenu_select sound made by wav2c

extern const unsigned int sfxmenu_select_sampleRate;
extern const unsigned int sfxmenu_select_length;
extern const signed char sfxmenu_select_data[];
