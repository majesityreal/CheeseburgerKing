// sfx_player_hurt sound made by wav2c

extern const unsigned int sfx_player_hurt_sampleRate;
extern const unsigned int sfx_player_hurt_length;
extern const signed char sfx_player_hurt_data[];
