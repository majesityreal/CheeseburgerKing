// map1Song sound made by wav2c

extern const unsigned int map1Song_sampleRate;
extern const unsigned int map1Song_length;
extern const signed char map1Song_data[];
