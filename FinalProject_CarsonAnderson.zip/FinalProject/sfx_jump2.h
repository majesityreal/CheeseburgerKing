// sfx_jump2 sound made by wav2c

extern const unsigned int sfx_jump2_sampleRate;
extern const unsigned int sfx_jump2_length;
extern const signed char sfx_jump2_data[];
