// bossSong sound made by wav2c

extern const unsigned int bossSong_sampleRate;
extern const unsigned int bossSong_length;
extern const signed char bossSong_data[];
