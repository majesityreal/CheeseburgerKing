// sfx_lettuce_roll sound made by wav2c

extern const unsigned int sfx_lettuce_roll_sampleRate;
extern const unsigned int sfx_lettuce_roll_length;
extern const signed char sfx_lettuce_roll_data[];
